% ============================================================
% plot_figure3_cv_q_r2007b.m
% Figure 3 - Specific Heat vs Temperature for different q
% MATLAB R2007b compatible
% Based on the actual equation:
%
% C_V,q(T) = T^alpha * [A1 + A2*(1-q)*T] / (1 + (T/TD)^n)
%
% Export:
%   EPS (vector), TIFF 1200 dpi, PNG 600 dpi
% ============================================================

clear all;
close all;
clc;

% ------------------------------------------------------------
% PARAMETERS
% ------------------------------------------------------------
alpha = 1.00;
A1    = 0.0025;
A2    = 1.5e-5;
TD    = 180.0;
n     = 2.8;

qvals = [0.98 1.00 1.02];

T = linspace(0.0,300.0,1400);

% ------------------------------------------------------------
% MODEL
% ------------------------------------------------------------
Cv1 = (T.^alpha) .* (A1 + A2.*(1 - qvals(1)).*T) ./ (1 + (T./TD).^n);
Cv2 = (T.^alpha) .* (A1 + A2.*(1 - qvals(2)).*T) ./ (1 + (T./TD).^n);
Cv3 = (T.^alpha) .* (A1 + A2.*(1 - qvals(3)).*T) ./ (1 + (T./TD).^n);

% ------------------------------------------------------------
% FIGURE SETUP
% ------------------------------------------------------------
fig = figure('Color','w');
set(fig,'Units','inches');
set(fig,'Position',[1.0 1.0 6.8 5.2]);
set(fig,'PaperUnits','inches');
set(fig,'PaperSize',[6.8 5.2]);
set(fig,'PaperPosition',[0 0 6.8 5.2]);
set(fig,'Renderer','painters');

axes1 = axes('Parent',fig);
hold(axes1,'on');

% ------------------------------------------------------------
% CONTRASTING COLORS
% ------------------------------------------------------------
col1 = [0.00 0.20 0.60];   % navy
col2 = [0.85 0.33 0.10];   % orange
col3 = [0.00 0.55 0.25];   % dark green

p1 = plot(T,Cv1,'-','Color',col1,'LineWidth',2.8);
p2 = plot(T,Cv2,'-','Color',col2,'LineWidth',2.8);
p3 = plot(T,Cv3,'-','Color',col3,'LineWidth',2.8);

% ------------------------------------------------------------
% AXES STYLE
% ------------------------------------------------------------
set(gca,...
    'FontName','Times New Roman',...
    'FontSize',18,...
    'LineWidth',1.2,...
    'Box','on',...
    'Layer','top',...
    'TickDir','in',...
    'TickLength',[0.020 0.020],...
    'XMinorTick','off',...
    'YMinorTick','off');

xlim([0 300]);
ymax = max([max(Cv1) max(Cv2) max(Cv3)]);
ylim([0 1.08*ymax]);

set(gca,'XTick',0:50:300);

xlabel('Temperature (K)',...
    'FontName','Times New Roman','FontSize',22);
ylabel('Specific heat C_V(T)',...
    'FontName','Times New Roman','FontSize',22);

title('Specific heat vs temperature for different $q$', 'Interpreter', 'latex');
set(gca,'Position',[0.15 0.15 0.80 0.77]);

leg = legend([p1 p2 p3],...
    ['q = ' num2str(qvals(1),'%0.2f')],...
    ['q = ' num2str(qvals(2),'%0.2f')],...
    ['q = ' num2str(qvals(3),'%0.2f')],...
    'Location','NorthEast');

set(leg,...
    'FontName','Times New Roman',...
    'FontSize',15,...
    'Box','off');

hold off;

% ------------------------------------------------------------
% EXPORT FOR PUBLICATION
% ------------------------------------------------------------
basename = 'Figure3_specific_heat_actual_equation_R2007b';

print(fig, basename, '-depsc2', '-painters');
print(fig, basename, '-dtiff', '-r1200');
print(fig, basename, '-dpng', '-r600');