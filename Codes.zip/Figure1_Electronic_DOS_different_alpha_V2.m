% ============================================================
% Figure 1 - Electronic DOS for different alpha
% MATLAB R2007b compatible
% No local functions
%
% use_displayed_figure = 1  -> normalized/displayed-style figure
% use_displayed_figure = 0  -> literal DOS from the manuscript
%
% Publication-quality export:
%   EPS (vector), TIFF 1200 dpi, PNG 600 dpi
% ============================================================

clear all;
close all;
clc;

% -----------------------------
% USER OPTION
% -----------------------------
use_displayed_figure = 0;   % 1 = displayed/normalized
                            % 0 = literal equation

% -----------------------------
% Parameters
% -----------------------------
alpha_vals = [1.5 2.0 2.5 3.0];
q  = 1.0;        % fixed q for Figure 1
E0 = 0.1;        % threshold energy
V_alpha = 1.0;   % kept from original seed script

% -----------------------------
% Figure setup
% -----------------------------
fig = figure('Color','w');
set(fig,'Units','inches');
set(fig,'Position',[1.0 1.0 6.8 5.2]);
set(fig,'PaperUnits','inches');
set(fig,'PaperSize',[6.8 5.2]);
set(fig,'PaperPosition',[0 0 6.8 5.2]);
set(fig,'Renderer','painters');

axes1 = axes('Parent',fig);
hold(axes1,'on');

% -----------------------------
% High-contrast colors
% -----------------------------
col1 = [0.00 0.45 0.74];   % blue
col2 = [0.85 0.33 0.10];   % orange
col3 = [0.47 0.67 0.19];   % green
col4 = [0.64 0.08 0.18];   % dark red

% -----------------------------
% Build curves
% -----------------------------
if use_displayed_figure == 1

    % -----------------------------------------
    % DISPLAYED / NORMALIZED STYLE
    % -----------------------------------------
    E = linspace(0.0005,1.0,1600);

    alpha = alpha_vals(1);
    Ge1 = E.^(alpha - 1);

    alpha = alpha_vals(2);
    Ge2 = E.^(alpha - 1);

    alpha = alpha_vals(3);
    Ge3 = E.^(alpha - 1);

    alpha = alpha_vals(4);
    Ge4 = E.^(alpha - 1);

    p1 = plot(E,Ge1,'-','Color',col1,'LineWidth',2.8);
    p2 = plot(E,Ge2,'-','Color',col2,'LineWidth',2.8);
    p3 = plot(E,Ge3,'-','Color',col3,'LineWidth',2.8);
    p4 = plot(E,Ge4,'-','Color',col4,'LineWidth',2.8);

    xlim([0 1.0]);
    ylim([0 1.05]);
    set(gca,'XTick',0:0.2:1.0);

else

    % -----------------------------------------
    % LITERAL EQUATION WITH IMPROVED VISUAL SCALE
    % g_q(E) ~ (E-E0)^(alpha/2 - 1) * [1 + (1-q)(E-E0)]
    %
    % For q = 1, this becomes:
    % g(E) ~ (E-E0)^(alpha/2 - 1)
    %
    % For alpha < 2, the DOS diverges at E -> E0+.
    % To improve the visual appeal while preserving the
    % literal analytical form, we only omit an extremely
    % narrow threshold neighborhood from the PLOT.
    % -----------------------------------------

    Emax = 2.0;

    % full grid for stable evaluation
    E_full = linspace(E0 + 1.0e-5, Emax, 4000);

    % small trimming distance from threshold for plotting only
    dE_plot = 0.035 * (Emax - E0);   % visual trim
    Eplot_min = E0 + dE_plot;

    idx = find(E_full >= Eplot_min);
    E = E_full(idx);

    % alpha = 1.5
    alpha = alpha_vals(1);
    pref1 = (2 * V_alpha) / (2 * pi)^alpha;
    Ge1 = pref1 * (E - E0).^(alpha/2 - 1) .* (1 + (1 - q)*(E - E0));

    % alpha = 2.0
    alpha = alpha_vals(2);
    pref2 = (2 * V_alpha) / (2 * pi)^alpha;
    Ge2 = pref2 * (E - E0).^(alpha/2 - 1) .* (1 + (1 - q)*(E - E0));

    % alpha = 2.5
    alpha = alpha_vals(3);
    pref3 = (2 * V_alpha) / (2 * pi)^alpha;
    Ge3 = pref3 * (E - E0).^(alpha/2 - 1) .* (1 + (1 - q)*(E - E0));

    % alpha = 3.0
    alpha = alpha_vals(4);
    pref4 = (2 * V_alpha) / (2 * pi)^alpha;
    Ge4 = pref4 * (E - E0).^(alpha/2 - 1) .* (1 + (1 - q)*(E - E0));

    p1 = plot(E,Ge1,'-','Color',col1,'LineWidth',2.8);
    p2 = plot(E,Ge2,'-','Color',col2,'LineWidth',2.8);
    p3 = plot(E,Ge3,'-','Color',col3,'LineWidth',2.8);
    p4 = plot(E,Ge4,'-','Color',col4,'LineWidth',2.8);

    % Better visual scale from the actually displayed range
    ymax = max([max(Ge1) max(Ge2) max(Ge3) max(Ge4)]);
    ymin = 0;

    xlim([Eplot_min Emax]);
    ylim([ymin 1.08*ymax]);

    % optional nice ticks
    set(gca,'XTick',0.2:0.2:2.0);

end

% Dummy legend handle for fixed q
pq = plot(NaN,NaN,'LineStyle','none','Marker','none','Color','w');

% -----------------------------
% Axes style
% -----------------------------
set(gca,...
    'FontName','Times New Roman',...
    'FontSize',18,...
    'LineWidth',1.2,...
    'Box','on',...
    'Layer','top',...
    'TickDir','in',...
    'TickLength',[0.020 0.020],...
    'XMinorTick','off',...
    'YMinorTick','off');

xlabel('Energy (E)', 'FontName','Times New Roman', 'FontSize',22);
ylabel('DOS(E)',     'FontName','Times New Roman', 'FontSize',22);

% No title inside figure for publication
 title('Electronic density of states for different \alpha');

set(gca,'Position',[0.16 0.16 0.79 0.77]);

% -----------------------------
% Legend
% -----------------------------
leg = legend([p1 p2 p3 p4 pq], ...
    '\alpha = 1.5', ...
    '\alpha = 2.0', ...
    '\alpha = 2.5', ...
    '\alpha = 3.0', ...
    ['fixed q = ' num2str(q,'%0.2f')], ...
    'Location','NorthEast');

set(leg,...
    'FontName','Times New Roman',...
    'FontSize',15,...
    'Box','off');

hold off;

% -----------------------------
% Export for publication
% -----------------------------
if use_displayed_figure == 1
    basename = 'Figure1_Electronic_DOS_displayed_style_R2007b';
else
    basename = 'Figure1_Electronic_DOS_literal_visual_R2007b';
end

% Vector EPS (best)
print(fig, basename, '-depsc2', '-painters');

% High-resolution TIFF
print(fig, basename, '-dtiff', '-r1200');

% PNG preview
print(fig, basename, '-dpng', '-r600');