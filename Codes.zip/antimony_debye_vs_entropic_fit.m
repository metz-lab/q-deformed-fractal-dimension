% MATLAB 2023b Script - Curve Fit: Debye and Entropic Model for Antimony 

% Load data from .txt file
data = readmatrix('antimony_cp_data.txt');
T_data = data(:,1);
Cp_data = data(:,2);
T_fit = linspace(min(T_data), max(T_data), 500);

% Constants
R = 8.314462618 / 101.9613;  % J/g·K

% 1. Debye Model
debye_model = @(p, T) 9 * R * (T ./ p(1)).^3 .* ...
    arrayfun(@(x) integral(@(t) (t.^4 .* exp(t)) ./ (exp(t) - 1).^2, 0, p(1)/x), T) * p(2);

p0_debye = [400, 0.05];  % Initial guess
lb = [10, 0.001];
ub = [2000, 10];
opts = optimoptions('lsqcurvefit', 'Display', 'off');
p_debye = lsqcurvefit(debye_model, p0_debye, T_data, Cp_data, lb, ub, opts);
theta_D = p_debye(1);
scale = p_debye(2);
Cp_debye = debye_model(p_debye, T_fit);

% 2. Entropic Model (fitted)
entropic_model = @(p, T) T.^p(1) .* (p(2) + p(3) * (1 - p(4)) .* T) ./ ...
    (1 + (p(5) ./ T).^p(6));
p0_entr = [0.05, 0.3, 0.07, 0.99, 50, 2];
lb_e = [0, 0, 0, 0.9, 1, 0.5];
ub_e = [1, 2, 1, 1.1, 500, 10];
p_entropic = lsqcurvefit(entropic_model, p0_entr, T_data, Cp_data, lb_e, ub_e, opts);
alpha = p_entropic(1);
A1 = p_entropic(2);
A2 = p_entropic(3);
q = p_entropic(4);
TD = p_entropic(5);
n = p_entropic(6);
Cp_entropic = entropic_model(p_entropic, T_fit);

% Rótulos LaTeX
entropic_label = sprintf(['$\\mathrm{Entropic\\ fit:}\\ \\alpha = %.3f,\\ A_1 = %.4f,\\ A_2 = %.4f, \\ ' ...
                          '\\   q = %.4f, \\ T_D = %.1f\\ \\mathrm{K},\\ n = %.2f$'] , ...
                         alpha, A1, A2, q, TD, n);

debye_label = sprintf('$\\mathrm{Debye\\ fit:}\\ T_D = %.1f\\ \\mathrm{K},\\ scale = %.3f$', ...
                      theta_D, scale);

% Plot final com LaTeX
figure('Position', [100, 100, 800, 600]);
plot(T_data, Cp_data, 'ko', 'MarkerFaceColor', 'k', 'DisplayName', '$C_p$ Experimental'); hold on;
plot(T_fit, Cp_debye, 'b-', 'LineWidth', 2, 'DisplayName', debye_label);
plot(T_fit, Cp_entropic, 'r--', 'LineWidth', 2, 'DisplayName', entropic_label);

xlabel('Temperature (K)', 'Interpreter', 'latex');
ylabel('Specific heat $C_p$ (J/g$\cdot$K)', 'Interpreter', 'latex');
title('Antimony: Debye vs entropic model fit', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;
set(gca, 'FontSize', 11);

% Exportar figura
exportgraphics(gcf, 'antimony_debye_vs_entropic_fit.png', 'Resolution', 300);
