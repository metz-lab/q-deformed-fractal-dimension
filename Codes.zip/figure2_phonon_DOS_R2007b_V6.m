% ============================================================
% Figure 2 - Publication-quality phonon DOS for different q
% MATLAB R2007b compatible
% Fixed alpha = 2.5
% Correct formula:
% Gp_q(w) = w^(alpha-1) * [1 + (1-q) w]
% ============================================================

clear all;
close all;
clc;

% -----------------------------
% Parameters
% -----------------------------
alpha = 2.5;
qvals = [0.95 1.00 1.05];
w = linspace(0.0,1.0,1200);

% -----------------------------
% Correct q-deformed phonon DOS
% -----------------------------
Gp_q095 = w.^(alpha - 1) .* (1 + (1 - qvals(1)).*w);
Gp_q100 = w.^(alpha - 1) .* (1 + (1 - qvals(2)).*w);
Gp_q105 = w.^(alpha - 1) .* (1 + (1 - qvals(3)).*w);

% -----------------------------
% Figure setup
% -----------------------------
fig = figure('Color','w');
set(fig,'Units','inches');
set(fig,'Position',[1.0 1.0 6.8 5.2]);
set(fig,'PaperUnits','inches');
set(fig,'PaperSize',[6.8 5.2]);
set(fig,'PaperPosition',[0 0 6.8 5.2]);
set(fig,'Renderer','painters');

axes1 = axes('Parent',fig);
hold(axes1,'on');

% -----------------------------
% High-contrast colors
% -----------------------------
col1 = [0.00 0.45 0.74];   % blue   -> q = 0.95
col2 = [0.85 0.33 0.10];   % orange -> q = 1.00
col3 = [0.49 0.18 0.56];   % purple -> q = 1.05

p1 = plot(w,Gp_q095,'-','Color',col1,'LineWidth',2.6);
p2 = plot(w,Gp_q100,'-','Color',col2,'LineWidth',2.6);
p3 = plot(w,Gp_q105,'-','Color',col3,'LineWidth',2.6);

% Dummy handle only for legend entry of alpha
p4 = plot(NaN,NaN,'LineStyle','none','Marker','none','Color','w');

% -----------------------------
% Axes styling
% -----------------------------
set(gca,...
    'FontName','Times New Roman',...
    'FontSize',18,...
    'LineWidth',1.2,...
    'Box','on',...
    'Layer','top',...
    'TickDir','in',...
    'TickLength',[0.020 0.020],...
    'XMinorTick','off',...
    'YMinorTick','off');

xlim([0 1.0]);
ylim([0 1.10*max(Gp_q095)]);
set(gca,'XTick',0:0.2:1.0);

xlabel('Phonon frequency (\omega)',...
    'FontName','Times New Roman','FontSize',22);
ylabel('DOS(\omega)',...
    'FontName','Times New Roman','FontSize',22);

% No title inside figure for publication
title('Electronic density of states for different $q$', 'Interpreter', 'latex');
set(gca,'Position',[0.16 0.16 0.79 0.77]);

% -----------------------------
% Legend
% -----------------------------
leg = legend([p1 p2 p3 p4],...
    'q = 0.95',...
    'q = 1.00',...
    'q = 1.05',...
    ['\alpha = ' num2str(alpha)],...
    'Location','NorthWest');

set(leg,...
    'FontName','Times New Roman',...
    'FontSize',15,...
    'Box','off');

hold off;

% ============================================================
% EXPORTS FOR PUBLICATION
% ============================================================
print(fig,'Figure2_phonon_DOS_alpha2p5_publication','-depsc2','-painters');
print(fig,'Figure2_phonon_DOS_alpha2p5_publication','-dtiff','-r1200');
print(fig,'Figure2_phonon_DOS_alpha2p5_publication','-dpng','-r600');